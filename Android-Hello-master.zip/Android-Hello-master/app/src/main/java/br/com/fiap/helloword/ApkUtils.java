package br.com.fiap.helloword;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.os.Build;
import android.support.v4.content.FileProvider;

import org.xutils.x;

import java.io.File;

public class ApkUtils {


//    /** 安装一个apk文件 */
//    public static void install(Context context, File uriFile) {
//        Intent intent = new Intent(Intent.ACTION_VIEW);
//        intent.setDataAndType(Uri.fromFile(uriFile), "application/vnd.android.package-archive");
//        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        context.startActivity(intent);
//    }

    public static void install(Context context,File file){
        try{//这里有文件流的读写，需要处理一下异常
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Uri uri;
            if (Build.VERSION.SDK_INT == Build.VERSION_CODES.N){
                //如果SDK版本 =24，即：Build.VERSION.SDK_INT  = 24
                String packageName = context.getApplicationContext().getPackageName();
                String authority = new StringBuilder(packageName).append(".provider").toString();
                uri = FileProvider.getUriForFile(context, authority, file);
                intent.setDataAndType(uri, "application/vnd.android.package-archive");
            } else{
                uri = Uri.fromFile(file);
                intent.setDataAndType(uri, "application/vnd.android.package-archive");
            }
            context.startActivity(intent);
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void installApk(File file, String fileProvider,Context context) {
        ApplicationInfo info = x.app().getApplicationInfo();
        Uri apkUri;
        if (info.targetSdkVersion >= 24 && Build.VERSION.SDK_INT >= 24) {
            apkUri = FileProvider.getUriForFile(context, fileProvider, file);
        } else {
            apkUri = Uri.fromFile(file);
        }
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
        context.startActivity(intent);
    }
}


