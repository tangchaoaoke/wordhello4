package br.com.fiap.helloword;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class StreamTool {


    /*
     * 读取流中的数据
     * */
    public static byte[] read(InputStream instream) throws Exception{
        ByteArrayOutputStream outStream=new ByteArrayOutputStream();
        //定义一个字节数组
        byte[] buffer=new byte[1024];
        //读满数组，就会返回(返回的是int型，代表读取的数组长度)
        //当返回值为-1时说明已经读完
        int len=0;
        while((len = instream.read(buffer)) !=-1){
            //buffer有多少数据就读多少
            outStream.write(buffer, 0, len);
        }
        instream.close();
        return outStream.toByteArray();
    }

}
