package br.com.fiap.helloword;

import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.lzy.okgo.OkGo;
import com.lzy.okgo.db.DownloadManager;
import com.lzy.okgo.model.Progress;
import com.lzy.okgo.request.GetRequest;
import com.lzy.okserver.OkDownload;
import com.lzy.okserver.download.DownloadListener;
import com.lzy.okserver.download.DownloadTask;

import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DownLoadAty extends AppCompatActivity {


    private DownloadTask task;
    private NumberFormat numberFormat;
    private TextView netSpeed;
    private TextView tvProgress;
    private TextView downloadSize;
    private ProgressBar pbProgress;
    private Button download;
    private  File file;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download_details);
        pbProgress = findViewById(R.id.pbProgress);
        download = findViewById(R.id.start);
        netSpeed = findViewById(R.id.netSpeed);
        tvProgress = findViewById(R.id.tvProgress);
        downloadSize = findViewById(R.id.downloadSize);
        numberFormat = NumberFormat.getPercentInstance();
        numberFormat.setMinimumFractionDigits(2);
        OkDownload.getInstance().setFolder(Environment.getExternalStorageDirectory().getAbsolutePath() + "/waimao/");

        PermissonUtils.with().setPermissionsListen(new PermissonUtils.PermissionListen() {
            @Override
            public void onSuccess() {

            }
        }).initPermisson(this);


        findViewById(R.id.btn_downapk).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                download("http://172.23.30.253:3001/1.0.15/lebo_1.0.15_debug.apk");
                download("http://qd.shouji.qihucdn.com/nqapk/sjzs2_100000003_5f1b01567c55662989/201012/d1208503899d47cab3251dfaa06aaf95/appstore-300090091.apk");
            }
        });

        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

              String  text =  download.getText().toString();
                switch (text){
                    case "安装":
                        ApkUtils.installApk(file, "br.com.fiap.helloword.FileProvider", DownLoadAty.this);
                        break;
                    case "下载中":
                        if (task!=null){
                            task.pause();
                        }
                        break;
                    case "等待":
                        break;
                    case "出错":
                        break;
                    case "已暂停":
                        if (task!=null){
                            task.start();
                        }
                        break;
                }

            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    private  void download(String url){
//        // 写法一：从内存中获取
//        if (OkDownload.getInstance().hasTask(imgUrl)) {
//            task = OkDownload.getInstance().getTask(imgUrl)//
//                    .register(new DesListener("DesListener"))//
//                    .register(new LogDownloadListener());
//        }

        //写法二：从数据库中恢复
        Progress progress = DownloadManager.getInstance().get(url);

        if (progress!=null&&progress.status==Progress.FINISH){
            Toast.makeText(this,"文件已下载",Toast.LENGTH_SHORT).show();
            download.setText("安装");
            file = new File(progress.filePath);
            return;
        }

        if (progress!=null&&progress.status!=Progress.FINISH){
//            Toast.makeText(this,"未下载完成",Toast.LENGTH_SHORT).show();
            task = OkDownload.restore(progress)//
                    .register(new DesListener("DesListener"))//
                    .register(new LogDownloadListener());
            if (task != null) refreshUi(task.progress);
            Log.e("ssss",task.progress.url);
            task.start();
            return;
        }

        GetRequest<File> request = OkGo.<File>get(url)//
                .headers("aaa", "111")//
                .params("bbb", "222");
        task = OkDownload.request(url, request)//
//                        .priority(apk.priority)//
//                        .extra1(apk)//
                .save()
                .register(new DesListener("DesListener"))//
                .register(new LogDownloadListener());

         task.start();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (task != null) {
            task.unRegister("DesListener");
        }
    }

    private void refreshUi(Progress progress) {
        String currentSize = Formatter.formatFileSize(this, progress.currentSize);
        String totalSize = Formatter.formatFileSize(this, progress.totalSize);
        downloadSize.setText(currentSize + "/" + totalSize);
        String speed = Formatter.formatFileSize(this, progress.speed);
        netSpeed.setText(String.format("%s/s", speed));
        tvProgress.setText(numberFormat.format(progress.fraction));
        pbProgress.setMax(10000);
        pbProgress.setProgress((int) (progress.fraction * 10000));
        switch (progress.status) {
            case Progress.NONE:
                download.setText("...");
                break;
            case Progress.LOADING:
                download.setText("下载中");
                break;
            case Progress.PAUSE:
                download.setText("已暂停");
                break;
            case Progress.WAITING:
                download.setText("等待");
                break;
            case Progress.ERROR:
                download.setText("出错");
                break;
            case Progress.FINISH:
//                if (ApkUtils.isAvailable(this, new File(progress.filePath))) {
//                    download.setText("卸载");
//                } else {
//                    download.setText("安装");
//                }
                file = new File(task.progress.filePath);
                download.setText("安装");
                break;
        }
    }


    private class DesListener extends DownloadListener {

        DesListener(String tag) {
            super(tag);
        }

        @Override
        public void onStart(Progress progress) {
        }

        @Override
        public void onProgress(Progress progress) {
            refreshUi(progress);
        }

        @Override
        public void onFinish(File file, Progress progress) {
//            Toast.makeText(MainActivity.this,"sss2",Toast.LENGTH_SHORT).show();
//            MainActivity.this.file = file;
        }

        @Override
        public void onRemove(Progress progress) {
        }

        @Override
        public void onError(Progress progress) {
            Throwable throwable = progress.exception;
            if (throwable != null) throwable.printStackTrace();
        }
    }


}
