package br.com.fiap.helloword;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.lzy.okgo.OkGo;
import com.lzy.okgo.model.Progress;
import com.lzy.okgo.request.GetRequest;
import com.lzy.okserver.OkDownload;
import com.lzy.okserver.download.DownloadListener;
import com.lzy.okserver.download.DownloadTask;

import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DownImgAty extends AppCompatActivity {

    private Handler myhandler;
    private String t=null;


    private EditText edit_01;
    private TextView tv_01;
    private String[] srt;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_img);
        edit_01 =findViewById(R.id.edit_01);
        tv_01 =findViewById(R.id.tv_01);
        OkDownload.getInstance().setFolder(Environment.getExternalStorageDirectory().getAbsolutePath() + "/waimao/");

        edit_01.setText("https://jable.tv/categories/chinese-subtitle/?sort_by=release_year&from=1");


        findViewById(R.id.btn_01).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               test01(edit_01.getText().toString());
            }
        });
        findViewById(R.id.btn_02).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if (srt==null) return;
                saveImg();
            }
        });

        myhandler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                // TODO Auto-generated method stub
                if(msg.what==0x111){
//                    text.setText(t);
                    String[] srt=   returnImageUrlsFromHtml(t);

                    if (srt==null){
                        Toast.makeText(DownImgAty.this, "未匹配到图片链接", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    StringBuffer stringBuffer = new StringBuffer();
                    for (int i=0;i<srt.length;i++){
                        stringBuffer.append(srt[i]);
                        stringBuffer.append("\n");
                    }
                    tv_01.setText(stringBuffer.toString());
                }else{
                    Toast.makeText(DownImgAty.this, "失败，请检查网络", Toast.LENGTH_SHORT).show();
                }
                super.handleMessage(msg);
            }
        };

    }


    private  void saveImg(){

        for (int i=0;i<srt.length;i++){
            GetRequest<File> request = OkGo.<File>get(srt[i])//
                    .headers("aaa", "111")//
                    .params("bbb", "222");
            DownloadTask task = OkDownload.request(srt[i], request)//
//                        .priority(apk.priority)//
//                        .extra1(apk)//
                    .save()
                    .register(new DesListener("DesListener"))
                    .register(new LogDownloadListener());

            task.start();
        }
    }
    private class DesListener extends DownloadListener {

        DesListener(String tag) {
            super(tag);
        }

        @Override
        public void onStart(Progress progress) {
        }

        @Override
        public void onProgress(Progress progress) {
//            refreshUi(progress);
        }

        @Override
        public void onFinish(File file, Progress progress) {
//            Toast.makeText(MainActivity.this,"sss2",Toast.LENGTH_SHORT).show();
//            MainActivity.this.file = file;
        }

        @Override
        public void onRemove(Progress progress) {
        }

        @Override
        public void onError(Progress progress) {
            Throwable throwable = progress.exception;
            if (throwable != null) throwable.printStackTrace();
        }
    }



    /**
     * 获取html中的所有图片
     *
     * @param html
     * @return
     */
    public static String[] returnImageUrlsFromHtml(String html) {
        List<String> imageSrcList = new ArrayList<String>();
        String htmlCode = html;
        Pattern p = Pattern.compile("<img\\b[^>]*\\bsrc\\b\\s*=\\s*('|\")?([^'\"\n\r\f>]+(\\.jpg|\\.bmp|\\.eps|\\.gif|\\.mif|\\.miff|\\.png|\\.tif|\\.tiff|\\.svg|\\.wmf|\\.jpe|\\.jpeg|\\.dib|\\.ico|\\.tga|\\.cut|\\.pic|\\b)\\b)[^>]*>", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(htmlCode);
        String quote = null;
        String src = null;
        while (m.find()) {
            quote = m.group(1);
            src = (quote == null || quote.trim().length() == 0) ? m.group(2).split("//s+")[0] : m.group(2);
            imageSrcList.add(src);
            Log.e("imageSrcList", src);
        }
        if (imageSrcList == null || imageSrcList.size() == 0) {
            Log.e("imageSrcList", "未匹配到图片链接");
            return null;
        }
        return imageSrcList.toArray(new String[imageSrcList.size()]);
    }

    private  void test01(final String url){
        Thread th = new Thread(){
            public void run() {
                try {
                    t=getHtml(url);
                    Message m = new Message();
                    if(t!=null){
                        m.what=0x111;//用户自定义的消息代码
                        myhandler.sendMessage(m);//发送信息
                    }else{
                        m.what=0x110;
                        myhandler.sendMessage(m);
                        return;
                    }
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        };
        th.start();
    }

    public static String getHtml(String path) throws Exception{
        //将path包装成一个URL对象
        URL url=new URL(path);
        //取得链接对象(基于HTTP协议链接对象)
        HttpURLConnection conn=(HttpURLConnection) url.openConnection();
        //设置超时时间
        conn.setConnectTimeout(5000);
        //设置请求方式
        conn.setRequestMethod("GET");
        //判断请求是否成功(看一下getResponseCode)
        if(conn.getResponseCode()==200){
            InputStream instream=conn.getInputStream();
            //流的工具类，专门从流中读取数据(返回的是二进制数据)
            byte[] data=StreamTool.read(instream);
            String html= new String(data,"UTF-8");
            return html;
        }
        return null;
    }

}
